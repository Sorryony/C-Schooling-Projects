/* -----------------------------------------------------------------------------

FILE:              Celsius_to_Fahrenheit.cpp
DESCRIPTION:       A Small Celsius and Fahrenhiet caculator
COMPILER:          MS Visual Studio 2017  C++ compiler
NOTES:             

MODIFICATION HISTORY: 2017-10-23 started project
					  2017-10-30 Finshed

Author             Date               Version
---------------    ----------         --------------
Anthony Giordano  	2017-10-23         1.0
----------------------------------------------------------------------------- */



#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>

using namespace std;


//proto functions
double C_F();
double Cel_Fah();
double Fah_Cel();

//Global
bool on = true;
const string PROGRAMMER_NAME = "Anthony Giordano";

/* -----------------------------------------------------------------------------
FUNCTION:          main()
DESCRIPTION:       Main Function
RETURNS:           0
NOTES:             
------------------------------------------------------------------------------- */
int main()
{
	cout << "Welcome to converstion for Celsius and Fahrenheit!" << endl;

	while(on)
	{
		system("cls");
		C_F();
		system("PAUSE");
	}
	
	
	cout << "Programmed by: " << PROGRAMMER_NAME << " -- ";
	cout << __DATE__ << "  " __TIME__ << endl;
	cout << endl;

	system("pause");

	return 0;

}
/* -----------------------------------------------------------------------------
FUNCTION:          C_F()
DESCRIPTION:       Ask for the choice in which to want to convert.
RETURNS:           0
NOTES:             
------------------------------------------------------------------------------- */

double C_F()
{
	char choice;
	cout << "which way would you like to convert?" << endl << endl;
	cout << "Press c to convert Celsius to Fahrenheit" << endl << endl;
	cout << "Or press f to conver Fahrenheit to Celsius" << endl << endl;
	cout << "any other letter will quit this program" << endl << endl;
	cin >> choice;

	switch (choice)
	{
	case'c':Cel_Fah();
			break;
	case'f':Fah_Cel();
			break;
	default: on = false;
			break;
	}
	return 0;
}

/* -----------------------------------------------------------------------------
FUNCTION:          Cel_Fah()
DESCRIPTION:       Converts Celsius to Fahrenhiet
RETURNS:           Total
NOTES:             
------------------------------------------------------------------------------- */


double Cel_Fah()
{
		double cel;

	cout << "Enter the tempeter in Celsius : ";
	cin >> cel;

	double Total = cel * 1.8 + 32;

	cout << endl << setprecision(3) << cel << " Celsius is: " << Total << " Farhrenheit" << endl;
	return Total;
}
/* -----------------------------------------------------------------------------
FUNCTION:          Fah_Cel()
DESCRIPTION:       Converts Fahrenhiet to Celsius
RETURNS:           Total
NOTES:             
------------------------------------------------------------------------------- */

double Fah_Cel()
{
	double fah;
	
	cout << "Enter the tempeter in Fahreheit : ";
	cin >> fah;
	
	double Total = (fah-32)*5/9;
	cout << endl << setprecision(3) << fah << " Fahrenhiet is: " << Total << " Celsius" << endl;
	return Total; 
}
