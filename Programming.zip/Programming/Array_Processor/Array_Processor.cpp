/* -----------------------------------------------------------------------------

FILE:              Array_Processor.cpp
DESCRIPTION:       Template for building stand-alone programs
COMPILER:          MS Visual Studio 2017  C++ compiler
NOTES:				Took more time then expected

MODIFICATION HISTORY:
Author             Date               Version
---------------    ----------         --------------
Anthony Giordano   2017-11-22         1.0
started project with main interface for entering file name.

Anthony Giordano   2017-12-04		  1.1
got output file to work.

Anthony Giordano   2017-12-14		  1.2
added min, max, and adv.

Anthony Giordano   2017-12-16		  1.3
started working on histogram and mod and fixing small bugs.

Anthony Giordano   2017-12-16		  2.0
Finshed up project added histogram and mode.
----------------------------------------------------------------------------- */

#include <iostream>
#include <cmath>
#include <iomanip>
#include <windows.h>
#include <time.h>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

//proto
int Raw(int[], ifstream& numbers);
int minimum(int[], int);
int maximum(int[], int);
double advrage(int[], int);
double med(int[], int);
int getMode(int [], int);

void selectionSort(int[], int);
void histogram(int[], int, ofstream& out_numbers);

void histogram_out(int[], int, ofstream& out_numbers);
void output(int, double, double, int, double,int, ofstream& out_numbers);

const string PROGRAMMER_NAME = "Anthony Giordano";
// Global constant
/* -----------------------------------------------------------------------------
FUNCTION:          main()
DESCRIPTION:       Runs main code data output
RETURNS:           0
NOTES:
------------------------------------------------------------------------------- */

int main()
{

	ifstream numbers;
	ofstream out_numbers;

	char file_name[20];
	cout << "Please enter the input file: ";
	cin >> file_name;
	system("cls");
	cout << "Please enter the input file: " << file_name << ".txt";
	cout << endl;
	string Rfile_name = file_name;







	numbers.open(Rfile_name + ".txt", ios::in);

	int  num_a[1000];

	int size = Raw(num_a, numbers);
	selectionSort(num_a, size);




	cout << endl;
	double min = minimum(num_a, size);
	double max = maximum(num_a, size);
	double adv = advrage(num_a, size);
	double median = med(num_a, size);
	int mod = getMode(num_a, size);
	histogram(num_a, size, out_numbers);
	cout << endl;


	char out_file[20];
	cout << "Please enter name of output file: ";
	cin >> out_file;
	string Rout_file = out_file;
	cout << endl << endl;

	out_numbers.open(Rout_file + ".txt", ios::out);

	out_numbers << "file name: " << Rfile_name << ".txt" << endl;
	out_numbers << "Output file name: "  << Rout_file << ".txt" << endl << endl;
	output(size, min, max, adv, median, mod , out_numbers);
	histogram_out(num_a, size, out_numbers);


	out_numbers << endl << endl;
	out_numbers << "Programmed by: " << PROGRAMMER_NAME << " -- ";
	out_numbers << __DATE__ << "  " __TIME__ << endl;
	out_numbers << endl;

	cout << "Programmed by: " << PROGRAMMER_NAME << " -- ";
	cout << __DATE__ << "  " __TIME__ << endl;
	cout << endl;

	system("pause");

	return 0;
}

/* -----------------------------------------------------------------------------
FUNCTION:          Raw()
DESCRIPTION:       Gives set numbers in txt file
RETURNS:           num
NOTES:             also cout's
----------------------------------------------------------------------------- */
int Raw(int a[], ifstream& numbers)
{
	int num;
	//cout << "Raw Data: ";

	for (num = 0; numbers >> a[num]; num++)
	{

		//cout << a[num] << " ";
	}
	cout << endl << "No. points: " << num;

	return num;
}

/* -----------------------------------------------------------------------------
FUNCTION:		   minimum()
DESCRIPTION:       get the min set number in txt file
RETURNS:           min
NOTES:             also cout's
----------------------------------------------------------------------------- */
int minimum(int a[], int size)
{
	int num;
	int min = a[0];
	cout << "Min: ";
	for (num = 0; num < size; num++)
	{
		if (a[num] < min)
		{
			min = a[num];
		}
	}
	cout << min;
	return min;
}

/* -----------------------------------------------------------------------------
FUNCTION:		   maximum()
DESCRIPTION:       get the max set number in txt file
RETURNS:           max
NOTES:             also cout's
----------------------------------------------------------------------------- */
int maximum(int a[], int size)
{
	int num;
	int max = a[0];
	cout << endl << "Max: ";
	for (num = 0; num < size; num++)
	{
		if (a[num] > max)
		{
			max = a[num];
		}
	}
	cout << max;
	return max;
}

/* -----------------------------------------------------------------------------
FUNCTION:		   advrage()
DESCRIPTION:       get the adverge set number in txt file
RETURNS:           adv
NOTES:             also cout's
----------------------------------------------------------------------------- */
double advrage(int a[], int size)
{
	int num;
	double sum = 0;
	double adv = 0;

	for (num = 0; num < size; num++)
	{
		sum += a[num];

	}
	adv = sum / size;
	cout << endl << "avg: " << adv << endl;

	return adv;

}

/* -----------------------------------------------------------------------------
FUNCTION:		   med()
DESCRIPTION:       get the median set number in txt file
RETURNS:           med
NOTES:             also cout's
----------------------------------------------------------------------------- */
double med(int a[], int size)
{
	double num = 0;
	double sum_2 = 0;
	double sum = 0;
	double med = 0;

	if (size % 2 == 0)
	{
		sum = a[(size / 2)];
		sum_2 = a[(size / 2) - 1];
		med = (sum + sum_2) / 2;
		cout << "med: " << med << endl;

	}
	else
	{
		med = a[(size / 2)];
		cout << "med: " << med << endl;
	}

	return med;

}

/* -----------------------------------------------------------------------------
FUNCTION:		   getMode()
DESCRIPTION:       get the mode set numbers in txt file
RETURNS:           mode_keeper[i],0;
NOTES:             also cout's
----------------------------------------------------------------------------- */
int getMode(int a[], int size)
{
	
	int tempF = 1;
	int freq = 0;
	int mode_keeper[5];
	int counter = 0;
	int val_holder = 0;
	int num_modes = 0;


	int mode = a[0];
	for (int i = 0; i < size; i++)
	{


		mode = a[i];
		if (val_holder == mode)
		{
			counter++;

			if (a[i] != a[i + 1])
			{
				if (counter > tempF)
				{
					tempF = counter;
					mode_keeper[0] = a[i - 1];
					num_modes = 1;
				}
				else if (counter == tempF)
				{

					mode_keeper[num_modes++] = a[i - 1];
				}
				counter = 0;
			}
		}


		val_holder = mode;

	}

	for (int i = 0; i < num_modes; i++)
	{
		cout << "Modes are: " << mode_keeper[i] << " ";
		return mode_keeper[i];
	}

	return 0;
}

/* -----------------------------------------------------------------------------
FUNCTION:		   selectionSort()
DESCRIPTION:       Sorts in asceding order the array from txt files
RETURNS:           nothing
NOTES:             Sorts in asending order
----------------------------------------------------------------------------- */
void selectionSort(int a[], int size)
{
	int startScan, minIndex, minValue;
	for (startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = a[startScan];

		for (int index = startScan + 1; index < size; index++)
		{
			if (a[index] < minValue)
			{
				minValue = a[index];
				minIndex = index;
			}
		}
		a[minIndex] = a[startScan];
		a[startScan] = minValue;
	}
}

/* -----------------------------------------------------------------------------
FUNCTION:		   histogram()
DESCRIPTION:       out puts a histogram for the array of numbers
RETURNS:           Nothing
NOTES:             also cout's
----------------------------------------------------------------------------- */
void histogram(int a[], int size, ofstream& out_numbers)
{
	int num;

	cout << endl << "HISTOGRAM" << endl << endl;
	

	
	for (int min = 1; min <= 901; min += 100)
	{
		cout << min << "-" << min+99;
		
		for (num = 0; num < size; num++)
		{

			if (a[num] <= min+99 && a[num] >= min) { cout << "*"; }

		}
		cout << endl;
	
	}

}

/* ------------------------------------------------------------------------------------
FUNCTION:		   histogram_out()
DESCRIPTION:       out puts a histogram for the array of numbers but to output file
RETURNS:           Nothing
NOTES:             cout's to output file
--------------------------------------------------------------------------------------*/
void histogram_out(int a[], int size, ofstream& out_numbers)
{
	int num;

	
	out_numbers << endl << "HISTOGRAM" << endl << endl;


	for (int min = 1; min <= 901; min += 100)
	{
		
		out_numbers << endl << min << "-" << min + 99;
		for (num = 0; num < size; num++)
		{

			if (a[num] <= min + 99 && a[num] >= min) { out_numbers << "*"; }


		}
		cout << endl;
	}

}

/* ------------------------------------------------------------------------------------------
FUNCTION:		   output()
DESCRIPTION:       outputs data to output file
RETURNS:           Nothing
NOTES:             All vaules are used as parameter.(no. point, min , max , adv , med, mods)
--------------------------------------------------------------------------------------------- */
void output(int a, double b, double c, int d, double e,int f, ofstream& out_numbers)
{
	out_numbers << endl << "No. points: " << a << endl;
	out_numbers << "Min: " << b << endl;
	out_numbers << "Max: " << c << endl;
	out_numbers << "Adv: " << d << endl;
	out_numbers << "Med: " << e << endl;
	out_numbers << "Mods are: " << f << endl;
}